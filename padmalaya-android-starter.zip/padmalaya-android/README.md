# Padmalaya Dairy — Android starter (v0.1)

Independent native Android Kotlin project based on the user's requested dairy workflow. Not a copy of another app's code or assets.

## Included
- Dashboard, farmer registration and listing
- Morning/evening cow/buffalo milk collection
- Liters, Fat, SNF and manually entered rate
- SQLite offline storage and last 100 collection records
- Machine connection selection placeholders (not functional)

## Not yet included
- Real USB FTDI RS232 or Bluetooth ESP32 connectivity
- Machine serial protocol parsing, receipt printing, login/authentication, cloud sync, automated fat/SNF pricing, payments
- Security hardening, export/backup, production signing

## Build using iPhone and GitHub
1. Create an empty GitHub repository, then upload the **contents of this folder** (including `.github/workflows/android-apk.yml`) using the GitHub website. GitHub mobile web may be cumbersome; use a repository import tool or browser desktop view if needed.
2. Open repository > Actions > Build Android APK > Run workflow (or push to `main`).
3. Wait for a successful build, open the workflow run and download artifact `PadmalayaDairy-debug-apk`.
4. Transfer downloaded ZIP/APK to an Android phone, unzip it, then install `app-debug.apk` (allow installs from that source if Android prompts).
5. This is a **debug APK for testing only**, not a production release.

Build may require fixes depending on upstream Gradle/Android plugin changes. No APK was compiled in the authoring environment.

## Data notes
- Milk quantity is in liters; weighing scale data in kg requires conversion/calibration before automatic entry.
- Manual rate per liter, no automated rate chart in this version.
- Data stored on the device; uninstalling may remove data. Avoid real business data until backup and security are implemented.
