plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.padmalaya.dairy"
 compileSdk = 35
 defaultConfig { applicationId = "com.padmalaya.dairy"; minSdk = 24; targetSdk = 28; versionCode = 1; versionName = "0.1.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
