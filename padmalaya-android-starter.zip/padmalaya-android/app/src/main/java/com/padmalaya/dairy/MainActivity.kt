package com.padmalaya.dairy

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class DairyDb(ctx: Context): SQLiteOpenHelper(ctx,"padmalaya.db",null,1) {
 override fun onCreate(db: SQLiteDatabase) {
  db.execSQL("CREATE TABLE farmers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT)")
  db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_id INTEGER, session TEXT, milk_type TEXT, liters REAL, fat REAL, snf REAL, rate REAL, amount REAL, created_at TEXT)")
 }
 override fun onUpgrade(db:SQLiteDatabase, oldVersion:Int,newVersion:Int) {}
 fun addFarmer(name:String,phone:String) { writableDatabase.execSQL("INSERT INTO farmers(name,phone) VALUES(?,?)",arrayOf(name,phone)) }
 fun addEntry(fid:Int,session:String,milk:String,liters:Double,fat:Double,snf:Double,rate:Double) {
  val date=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date())
  writableDatabase.execSQL("INSERT INTO entries(farmer_id,session,milk_type,liters,fat,snf,rate,amount,created_at) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(fid,session,milk,liters,fat,snf,rate,liters*rate,date))
 }
 fun farmers():List<Pair<Int,String>> { val out=mutableListOf<Pair<Int,String>>(); readableDatabase.rawQuery("SELECT id,name FROM farmers ORDER BY name",null).use { while(it.moveToNext())out.add(it.getInt(0) to it.getString(1)) }; return out }
 fun count(table:String):Int { readableDatabase.rawQuery("SELECT COUNT(*) FROM $table",null).use { it.moveToFirst(); return it.getInt(0) } }
 fun total():Double { readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM entries",null).use { it.moveToFirst(); return it.getDouble(0) } }
 fun history():List<String> { val out=mutableListOf<String>(); readableDatabase.rawQuery("SELECT e.created_at,f.name,e.session,e.milk_type,e.liters,e.fat,e.snf,e.amount FROM entries e LEFT JOIN farmers f ON f.id=e.farmer_id ORDER BY e.id DESC LIMIT 100",null).use { while(it.moveToNext()) out.add("${it.getString(0)}  •  ${it.getString(1)}\n${it.getString(2)} / ${it.getString(3)}  |  ${it.getDouble(4)} L  |  Fat ${it.getDouble(5)}%  SNF ${it.getDouble(6)}%\n₹%.2f".format(it.getDouble(7))) }; return out }
}

class MainActivity: Activity() {
 private lateinit var db:DairyDb
 private lateinit var root:LinearLayout
 private val blue=Color.rgb(12,85,169)
 private val teal=Color.rgb(22,151,141)
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); db=DairyDb(this); dashboard() }
 private fun page(title:String):LinearLayout {
  root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,250,254)) }
  setContentView(root)
  val header=TextView(this).apply { text="‹   $title"; textSize=22f; setTextColor(Color.WHITE); setBackgroundColor(blue); setPadding(24,36,18,36); setOnClickListener { dashboard() } }
  root.addView(header)
  val scroll=ScrollView(this); val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,20,22,20) }; scroll.addView(body); root.addView(scroll)
  return body
 }
 private fun text(parent:LinearLayout,s:String,size:Float=17f) { parent.addView(TextView(this).apply { text=s; textSize=size; setTextColor(Color.rgb(26,45,70)); setPadding(8,12,8,12) }) }
 private fun button(parent:LinearLayout,s:String,click:()->Unit) { parent.addView(Button(this).apply { text=s; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal)); setOnClickListener { click() } }) }
 private fun field(parent:LinearLayout,hint:String,decimal:Boolean=false):EditText { val f=EditText(this).apply { this.hint=hint; textSize=16f; inputType=if(decimal) android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL else android.text.InputType.TYPE_CLASS_TEXT }; parent.addView(f); return f }
 private fun spinner(parent:LinearLayout,items:List<String>):Spinner { val s=Spinner(this); s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,items); parent.addView(s); return s }
 private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
 private fun dashboard() { val p=page("Padmalaya Dairy"); text(p,"दूध संग्रह प्रणाली  •  Milk Collection",19f); text(p,"Farmers: ${db.count("farmers")}     Entries: ${db.count("entries")}"); text(p,"Total Collection Value: ₹%.2f".format(db.total()),20f)
  button(p,"＋ Morning Milk Collection") { collection("Morning") }; button(p,"＋ Evening Milk Collection") { collection("Evening") }
  button(p,"👤 Add Farmer") { addFarmer() }; button(p,"📋 Farmers") { farmerList() }; button(p,"📈 Collection History / Reports") { history() }; button(p,"₹ Fat / SNF Rate Chart") { rateChart() }; button(p,"🔌 Machine Connection") { connections() }
  text(p,"Version 0.1 • Offline local database • Demo/manual entry",13f)
 }
 private fun addFarmer() { val p=page("Add Farmer"); val name=field(p,"Farmer name / किसान का नाम"); val phone=field(p,"Mobile number (optional)"); button(p,"SAVE FARMER") { if(name.text.toString().isBlank()) toast("Enter farmer name") else { db.addFarmer(name.text.toString().trim(),phone.text.toString().trim()); toast("Farmer saved"); dashboard() } } }
 private fun farmerList() { val p=page("Farmers"); val list=db.farmers(); if(list.isEmpty())text(p,"No farmers yet"); list.forEach { text(p,"#${it.first}  ${it.second}") }; button(p,"＋ ADD FARMER") { addFarmer() } }
 private fun collection(session:String) { val p=page("$session Collection"); val farmers=db.farmers(); if(farmers.isEmpty()) { text(p,"First add a farmer to start milk collection."); button(p,"ADD FARMER") { addFarmer() }; return }
  text(p,"Farmer / किसान"); val farmer=spinner(p,farmers.map { "${it.first} — ${it.second}" }); text(p,"Milk Type"); val milk=spinner(p,listOf("Cow","Buffalo"));
  val liters=field(p,"Milk quantity (Liters)",true); val fat=field(p,"Fat (%)",true); val snf=field(p,"SNF (%)",true); val rate=field(p,"Rate (₹ / Liter)",true)
  text(p,"Rate is manually entered in this starter version. Confirm your actual Fat/SNF rate chart before use.",13f)
  button(p,"SAVE MILK ENTRY") { val l=liters.text.toString().toDoubleOrNull(); val f=fat.text.toString().toDoubleOrNull(); val n=snf.text.toString().toDoubleOrNull(); val r=rate.text.toString().toDoubleOrNull()
   if(l==null||f==null||n==null||r==null||l<=0||f<0||n<0||r<0||f>20||n>20)toast("Please enter valid liters, fat, SNF and rate") else { db.addEntry(farmers[farmer.selectedItemPosition].first,session,milk.selectedItem.toString(),l,f,n,r); toast("Saved • Amount ₹%.2f".format(l*r)); dashboard() }
  }
 }
 private fun history() { val p=page("Collection Reports"); val items=db.history(); if(items.isEmpty())text(p,"No collection records yet"); items.forEach { text(p,it) }; text(p,"Showing latest 100 entries • Stored on this device",13f) }
 private fun rateChart() { val p=page("Fat / SNF Rate Chart"); text(p,"Rate chart configuration will be added in the next version."); text(p,"For now, enter the approved rate manually during Milk Collection. Do not use sample rates for real payments.") }
 private fun connections() { val p=page("Machine Connection"); text(p,"Choose a future connection mode:"); button(p,"FTDI USB-to-RS232 + OTG") { toast("Not implemented yet: USB serial driver and device protocol required") }; button(p,"ESP32 Bluetooth Gateway") { toast("Not implemented yet: Bluetooth SPP and device protocol required") }; text(p,"Status: Not connected. No hardware readings are claimed.",14f) }
}
